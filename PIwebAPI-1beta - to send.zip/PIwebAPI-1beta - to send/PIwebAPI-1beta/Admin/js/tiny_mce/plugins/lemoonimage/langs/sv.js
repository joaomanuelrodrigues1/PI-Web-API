tinyMCE.addI18n('sv.lemoonimage',{
  desc: 'Infoga/Redigera bild',
  is_external: "Adressen du angav verkar vara till en extern bild. Vill du infoga http:// prefixet p\u00E5 l\u00E4nken?"
});
