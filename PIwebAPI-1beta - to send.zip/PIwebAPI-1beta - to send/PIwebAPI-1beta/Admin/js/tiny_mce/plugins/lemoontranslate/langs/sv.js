tinyMCE.addI18n('sv.lemoontranslate',{
  desc: '\u00D6vers\u00E4tt'
});
