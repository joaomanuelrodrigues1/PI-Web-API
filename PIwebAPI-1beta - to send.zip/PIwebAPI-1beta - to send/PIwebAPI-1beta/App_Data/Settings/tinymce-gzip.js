﻿<script type="text/javascript"> 
tinyMCE_GZ.init({
  plugins: "contextmenu,fullscreen,media,pagebreak,paste,table,codemirror,headings,lemoonimage,lemoonlink,pdw",
  themes: "advanced",
  languages: "en,sv",
  disk_cache: true,
  debug: false
});
</script>