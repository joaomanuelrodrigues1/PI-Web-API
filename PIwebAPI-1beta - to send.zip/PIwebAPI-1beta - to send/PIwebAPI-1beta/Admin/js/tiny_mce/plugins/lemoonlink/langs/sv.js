tinyMCE.addI18n('sv.lemoonlink',{
  desc: 'Infoga/Redigera  l\u00E4nk',
  is_email:"L\u00E4nken du angav verkar vara en e-post adress. Vill du infoga mailto: prefixet p\u00E5 l\u00E4nken?",
  is_external:"L\u00E4nken du angav verkar vara en extern adress. Vill du infoga http:// prefixet p\u00E5 l\u00E4nken?"
});
