tinyMCE.addI18n('en.codemirror', {
  title: 'HTML Source Editor',
  format: 'Format',
  format_title: 'Format the document',
  indent: 'Indent',
  indent_title: 'Indent the document',
  wordwrap: 'Word wrap'
});