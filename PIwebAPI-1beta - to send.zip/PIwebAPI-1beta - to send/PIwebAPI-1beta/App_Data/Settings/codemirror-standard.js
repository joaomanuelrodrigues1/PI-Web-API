﻿$('textarea.codemirror-standard').each(function (index) {
    var id = $(this).attr('id');
    CodeMirror.fromTextArea(document.getElementById(id), { mode: "text/html", tabSize: 2 });
});
