tinyMCE.addI18n('sv.codemirror', {
  title: 'HTML k\u00e4llkodsl\u00e4ge',
  format: 'Formatera',
  format_title: 'Formatera dokumentet',
  indent: 'Indentera',
  indent_title: 'Indentera dokumentet',
  wordwrap: 'Bryt ord'
});