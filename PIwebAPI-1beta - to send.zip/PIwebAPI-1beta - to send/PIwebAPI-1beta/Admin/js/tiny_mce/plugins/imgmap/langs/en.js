// UK lang variables

tinyMCE.addI18n('en.imgmap', {
	title : 'Image Map Editor',
	desc : 'Image Map Editor',
	remove : 'Remove map'
});
