tinyMCE.addI18n('en.lemoonimage',{
	desc : 'Insert/Edit image',
	is_external: "The URL you entered seems to be an external image, do you want to add the required http:// prefix?"
});
