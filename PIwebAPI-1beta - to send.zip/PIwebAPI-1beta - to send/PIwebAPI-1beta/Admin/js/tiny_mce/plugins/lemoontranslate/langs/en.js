tinyMCE.addI18n('en.lemoontranslate',{
	desc : 'Translate'
});
