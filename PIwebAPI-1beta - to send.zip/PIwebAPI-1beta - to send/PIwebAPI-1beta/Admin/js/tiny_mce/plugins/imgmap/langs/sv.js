tinyMCE.addI18n('sv.imgmap', {
	title : 'Redigera bildkarta',
	desc : 'Redigera bildkarta',
	remove : 'Ta bort bildkarta'
});
