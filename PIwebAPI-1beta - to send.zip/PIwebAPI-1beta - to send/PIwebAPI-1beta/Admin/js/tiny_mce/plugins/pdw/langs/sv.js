tinyMCE.addI18n('sv.pdw',{
  desc: 'Visa/d\u00f6lj menyer'
});
